/**
 * One-Time Data Migration Script: Legacy JSON Blobs -> Supabase Postgres Database
 * 
 * Usage:
 *   1. Install @supabase/supabase-js: npm install @supabase/supabase-js
 *   2. Set environment variables or update the constants below with your SUPABASE_URL and SERVICE_ROLE_KEY or ANON_KEY.
 *   3. Place your legacy gmi_records_v1.json and gmi_audit_v1.json in the same directory (or pass in inline JSON).
 *   4. Run: node migrate-data.js
 */

const fs = require('fs');
const path = require('path');
const { createClient } = require('@supabase/supabase-js');

// Configuration
const SUPABASE_URL = process.env.SUPABASE_URL || 'YOUR_SUPABASE_URL';
// Note: Use service_role key for server-side bulk migration, or anon key if authenticated as an owner staff profile
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || 'YOUR_SUPABASE_SERVICE_ROLE_KEY';

const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

async function runMigration() {
  console.log('--- Starting G.M.I. Tribunal Data Migration ---');

  // Load JSON files if present
  let oldRecords = [];
  let oldAudit = [];

  const recordsPath = path.join(__dirname, 'gmi_records_v1.json');
  const auditPath = path.join(__dirname, 'gmi_audit_v1.json');

  if (fs.existsSync(recordsPath)) {
    oldRecords = JSON.parse(fs.readFileSync(recordsPath, 'utf8'));
    console.log(`Found ${oldRecords.length} legacy records in gmi_records_v1.json.`);
  } else {
    console.log('gmi_records_v1.json not found. Pass data directly or ensure file exists.');
  }

  if (fs.existsSync(auditPath)) {
    oldAudit = JSON.parse(fs.readFileSync(auditPath, 'utf8'));
    console.log(`Found ${oldAudit.length} legacy audit entries in gmi_audit_v1.json.`);
  } else {
    console.log('gmi_audit_v1.json not found.');
  }

  // Fetch all staff profiles to map staff_id -> uuid
  const { data: staffProfiles, error: staffErr } = await supabase
    .from('staff_profiles')
    .select('id, staff_id');

  if (staffErr || !staffProfiles) {
    console.error('Failed to fetch staff profiles from Supabase. Make sure schema.sql and seed_staff.sql have been run.', staffErr);
    process.exit(1);
  }

  const staffMap = new Map();
  staffProfiles.forEach(p => staffMap.set(p.staff_id.toLowerCase(), p.id));

  // Default fallback user (e.g. system owner 'wicked') if addedBy isn't found
  const defaultStaffUuid = staffMap.get('wicked') || staffProfiles[0]?.id;

  // 1. Migrate Case Files & Offenses
  console.log('\nMigrating case files...');
  for (const r of oldRecords) {
    const staffUuid = staffMap.get((r.addedBy || '').toLowerCase()) || defaultStaffUuid;

    // Check if ID is a valid UUID, otherwise let Postgres generate or generate crypto UUID
    const isValidUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(r.id);
    const casePayload = {
      discord_username: r.discordUsername,
      discord_id: r.discordId || null,
      action_taken: r.action,
      notes: r.notes || null,
      added_by: staffUuid,
      added_by_label: r.addedByLabel || 'Staff',
      high_alert: Boolean(r.highAlert),
      created_at: r.timestamp || new Date().toISOString()
    };
    if (isValidUUID) {
      casePayload.id = r.id;
    }

    const { data: newCase, error: caseErr } = await supabase
      .from('case_files')
      .insert(casePayload)
      .select()
      .single();

    if (caseErr) {
      console.error(`Failed to insert case file for ${r.discordUsername}:`, caseErr.message);
      continue;
    }

    console.log(`Inserted case file: ${newCase.id} (${r.discordUsername})`);

    // Insert associated offenses
    if (r.offenses && Array.isArray(r.offenses)) {
      for (let i = 0; i < r.offenses.length && i < 3; i++) {
        const o = r.offenses[i];
        const { error: offErr } = await supabase
          .from('offenses')
          .insert({
            case_id: newCase.id,
            position: i + 1,
            offense_type: o.type || 'Other',
            severity: ['Minor', 'Moderate', 'Severe'].includes(o.severity) ? o.severity : 'Minor',
            custom_description: o.custom || null
          });

        if (offErr) {
          console.error(`Failed to insert offense position ${i + 1} for case ${newCase.id}:`, offErr.message);
        }
      }
    }
  }

  // 2. Migrate Audit Log Entries
  console.log('\nMigrating audit log entries...');
  for (const a of oldAudit) {
    const actorUuid = staffMap.get((a.actorId || '').toLowerCase()) || defaultStaffUuid;
    const isRecordIdUUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(a.recordId);

    const { error: auditErr } = await supabase
      .from('audit_log')
      .insert({
        action: ['add', 'delete'].includes(a.action) ? a.action : 'add',
        record_id: isRecordIdUUID ? a.recordId : null,
        actor_id: actorUuid,
        actor_label: a.actorLabel || 'Staff',
        summary: a.summary || 'Legacy log entry',
        created_at: a.timestamp || new Date().toISOString()
      });

    if (auditErr) {
      console.error(`Failed to insert audit entry (${a.summary}):`, auditErr.message);
    } else {
      console.log(`Inserted audit entry for ${a.actorLabel}: "${a.summary}"`);
    }
  }

  console.log('\n--- Migration Complete ---');
}

if (require.main === module) {
  runMigration().catch(err => {
    console.error('Migration runtime error:', err);
    process.exit(1);
  });
}

module.exports = { runMigration };
