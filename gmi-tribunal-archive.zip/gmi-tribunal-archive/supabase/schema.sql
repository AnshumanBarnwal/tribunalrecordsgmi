-- G.M.I. Tribunal Archive — Supabase Postgres Schema & Row Level Security

-- 1. Staff profiles table: maps Supabase Auth user IDs to staff roles and permissions
create table if not exists staff_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  staff_id text unique not null,          -- lowercase, e.g. 'proctor', 'wicked'
  display_label text not null,            -- e.g. 'Proctor', 'System Owner'
  role_level int not null default 1,
  can_add boolean not null default true,
  can_view_high_alert boolean not null default false,
  can_delete boolean not null default false,
  is_owner boolean not null default false,
  created_at timestamptz not null default now()
);

-- 2. Case files table: stores tribunal case files
create table if not exists case_files (
  id uuid primary key default gen_random_uuid(),
  discord_username text not null,
  discord_id text,
  action_taken text not null,
  notes text,
  added_by uuid not null references staff_profiles(id),
  added_by_label text not null,           -- snapshot of label at filing time
  high_alert boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists idx_case_files_username on case_files (lower(discord_username));
create index if not exists idx_case_files_high_alert on case_files (high_alert);
create index if not exists idx_case_files_created_at on case_files (created_at desc);

-- 3. Offenses table: up to 3 normalized offenses per case file
create table if not exists offenses (
  id uuid primary key default gen_random_uuid(),
  case_id uuid not null references case_files(id) on delete cascade,
  position smallint not null check (position between 1 and 3),
  offense_type text not null,
  severity text not null check (severity in ('Minor','Moderate','Severe')),
  custom_description text,
  unique (case_id, position)
);
create index if not exists idx_offenses_case_id on offenses (case_id);
create index if not exists idx_offenses_type on offenses (offense_type);

-- 4. Audit log table: append-only activity trail
create table if not exists audit_log (
  id uuid primary key default gen_random_uuid(),
  action text not null check (action in ('add','delete')),
  record_id uuid,                          -- not FK-enforced: the case row may already be gone
  actor_id uuid not null references staff_profiles(id),
  actor_label text not null,
  summary text not null,
  created_at timestamptz not null default now()
);
create index if not exists idx_audit_log_created_at on audit_log (created_at desc);

-- 5. Row Level Security Policies
alter table staff_profiles enable row level security;
alter table case_files enable row level security;
alter table offenses enable row level security;
alter table audit_log enable row level security;

-- Drop existing policies if re-running migration
drop policy if exists "read own profile" on staff_profiles;
drop policy if exists "read cases by clearance" on case_files;
drop policy if exists "insert cases if can_add" on case_files;
drop policy if exists "delete cases if can_delete" on case_files;
drop policy if exists "read offenses via parent case" on offenses;
drop policy if exists "insert offenses if can_add" on offenses;
drop policy if exists "delete offenses via parent case" on offenses;
drop policy if exists "insert audit entries" on audit_log;
drop policy if exists "owner reads audit log" on audit_log;

-- staff_profiles policies
create policy "read own profile" on staff_profiles
  for select using (id = auth.uid());

-- case_files policies
create policy "read cases by clearance" on case_files
  for select using (
    high_alert = false
    or exists (select 1 from staff_profiles p where p.id = auth.uid() and p.can_view_high_alert)
  );

create policy "insert cases if can_add" on case_files
  for insert with check (
    exists (select 1 from staff_profiles p where p.id = auth.uid() and p.can_add)
  );

create policy "delete cases if can_delete" on case_files
  for delete using (
    exists (select 1 from staff_profiles p where p.id = auth.uid() and p.can_delete)
  );

-- offenses policies
create policy "read offenses via parent case" on offenses
  for select using (
    exists (
      select 1 from case_files c
      where c.id = offenses.case_id
        and (c.high_alert = false
             or exists (select 1 from staff_profiles p where p.id = auth.uid() and p.can_view_high_alert))
    )
  );

create policy "insert offenses if can_add" on offenses
  for insert with check (
    exists (select 1 from staff_profiles p where p.id = auth.uid() and p.can_add)
  );

create policy "delete offenses via parent case" on offenses
  for delete using (
    exists (
      select 1 from case_files c
      where c.id = offenses.case_id
        and exists (select 1 from staff_profiles p where p.id = auth.uid() and p.can_delete)
    )
  );

-- audit_log policies
create policy "insert audit entries" on audit_log
  for insert with check (
    exists (select 1 from staff_profiles p where p.id = auth.uid() and (p.can_add or p.can_delete))
  );

create policy "owner reads audit log" on audit_log
  for select using (
    exists (select 1 from staff_profiles p where p.id = auth.uid() and p.is_owner)
  );
