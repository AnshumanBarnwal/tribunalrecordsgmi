-- Helper SQL script to populate staff_profiles for existing Auth Users in Supabase.
-- Run this in the Supabase SQL Editor AFTER creating the Auth users under their synthetic emails.

insert into staff_profiles (id, staff_id, display_label, role_level, can_add, can_view_high_alert, can_delete, is_owner)
select 
  u.id,
  'holy staff members',
  'Holy Staff Member',
  1,
  true,
  false,
  false,
  false
from auth.users u where u.email = 'holy.staff.members@staff.gmi.internal'
on conflict (staff_id) do update set
  id = excluded.id,
  display_label = excluded.display_label,
  role_level = excluded.role_level,
  can_add = excluded.can_add,
  can_view_high_alert = excluded.can_view_high_alert,
  can_delete = excluded.can_delete,
  is_owner = excluded.is_owner;

insert into staff_profiles (id, staff_id, display_label, role_level, can_add, can_view_high_alert, can_delete, is_owner)
select 
  u.id,
  'senior holy members',
  'Senior Holy Member',
  2,
  true,
  true,
  false,
  false
from auth.users u where u.email = 'senior.holy.members@staff.gmi.internal'
on conflict (staff_id) do update set
  id = excluded.id,
  display_label = excluded.display_label,
  role_level = excluded.role_level,
  can_add = excluded.can_add,
  can_view_high_alert = excluded.can_view_high_alert,
  can_delete = excluded.can_delete,
  is_owner = excluded.is_owner;

insert into staff_profiles (id, staff_id, display_label, role_level, can_add, can_view_high_alert, can_delete, is_owner)
select 
  u.id,
  'staff',
  'Staff',
  2,
  true,
  true,
  false,
  false
from auth.users u where u.email = 'staff@staff.gmi.internal'
on conflict (staff_id) do update set
  id = excluded.id,
  display_label = excluded.display_label,
  role_level = excluded.role_level,
  can_add = excluded.can_add,
  can_view_high_alert = excluded.can_view_high_alert,
  can_delete = excluded.can_delete,
  is_owner = excluded.is_owner;

insert into staff_profiles (id, staff_id, display_label, role_level, can_add, can_view_high_alert, can_delete, is_owner)
select 
  u.id,
  'proctor',
  'Proctor',
  3,
  true,
  true,
  true,
  false
from auth.users u where u.email = 'proctor@staff.gmi.internal'
on conflict (staff_id) do update set
  id = excluded.id,
  display_label = excluded.display_label,
  role_level = excluded.role_level,
  can_add = excluded.can_add,
  can_view_high_alert = excluded.can_view_high_alert,
  can_delete = excluded.can_delete,
  is_owner = excluded.is_owner;

insert into staff_profiles (id, staff_id, display_label, role_level, can_add, can_view_high_alert, can_delete, is_owner)
select 
  u.id,
  'custodian',
  'Custodian',
  3,
  true,
  true,
  true,
  false
from auth.users u where u.email = 'custodian@staff.gmi.internal'
on conflict (staff_id) do update set
  id = excluded.id,
  display_label = excluded.display_label,
  role_level = excluded.role_level,
  can_add = excluded.can_add,
  can_view_high_alert = excluded.can_view_high_alert,
  can_delete = excluded.can_delete,
  is_owner = excluded.is_owner;

insert into staff_profiles (id, staff_id, display_label, role_level, can_add, can_view_high_alert, can_delete, is_owner)
select 
  u.id,
  'wicked',
  'System Owner',
  99,
  true,
  true,
  true,
  true
from auth.users u where u.email = 'wicked@staff.gmi.internal'
on conflict (staff_id) do update set
  id = excluded.id,
  display_label = excluded.display_label,
  role_level = excluded.role_level,
  can_add = excluded.can_add,
  can_view_high_alert = excluded.can_view_high_alert,
  can_delete = excluded.can_delete,
  is_owner = excluded.is_owner;
